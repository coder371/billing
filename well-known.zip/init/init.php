<?php 
    ob_start();
    session_start();
    require_once "./conn/conn.php";
    require_once "./init/check.php";
    require_once "./init/GU.php";
    require_once "./init/config.php";
    require_once "./init/function.php";
