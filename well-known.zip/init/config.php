<?php 
    $config = [
        "start Work"            => "17-02-2020 08:00 AM" ,
        "Project Manger"        => "Abdalstar Abdo",
        "code"                  => "BitaSmart",
        "titleAr"               => "فواتير ",
        "titleEn"               => "fawatir",
        "site"                  => "https://majarah.com/bitasmart.com",
        "cdnAvatarClient"       => "https://majarah.com/bitasmart.com/dist-assets/images/client/",
        "cdnAvatarUsers"        => "https://majarah.com/bitasmart.com/dist-assets/images/users/",
        "cdnAssist"             => "https://majarah.com/bitasmart.com/dist-assets/images/assist/",
    ];