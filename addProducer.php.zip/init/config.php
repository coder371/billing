<?php 
    $config = [
        "start Work"            => "17-02-2020 08:00 AM" ,
        "Project Manger"        => "Abdalstar Abdo",
        "code"                  => "BitaSmart",
        "titleAr"               => "فواتير ",
        "titleEn"               => "fawatir",
        "site"                  => "https://" . $_SERVER['SERVER_NAME'] . '',
        "cdnAvatarClient"       => "https://" . $_SERVER['SERVER_NAME'] . "/dist-assets/images/client/",
        "cdnAvatarUsers"        => "https://" . $_SERVER['SERVER_NAME'] . "/dist-assets/images/users/",
        "cdnAssist"             => "https://" . $_SERVER['SERVER_NAME'] . "/dist-assets/images/assist/",
    ];